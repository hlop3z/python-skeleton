# python_skeleton
Cookie-Cutter Project

```
git clone https://github.com/hlop3z/python_skeleton
```
